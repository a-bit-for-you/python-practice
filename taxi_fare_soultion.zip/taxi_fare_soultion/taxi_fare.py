distance = float(input('Enter distance\n')) # in km
waiting_time = float(input('Enter waiting time\n')) # in minutes
start_time = input('Enter start time\n') #format '06.00 AM'
fare = 22

#Rs 15 will be charged extra per/km if the distance is above 1.5 km
if distance >= 1.5:
    fare += (distance - 1.5)* 15 
    
# Extra Waiting time 
fare += waiting_time*1.5

#Apply nigh rate

start_time=start_time[:2].replace("12","00")+start_time[2:]#replacing 12 with 0 for calculation
if "AM" in start_time and int(start_time[:2]+start_time[3:5])<=500 :
    fare += (fare/100*50)

print (f'Fare is Rs. {fare}')
